//Imagens do jogo:

//var 
let imageRoad;
let imageActor;
let imageCars;
let imageCar;
let imageCarTwo;
let imageCarTree;
let imageTrucks;
let imageTruck;
let imageTruckTwo;
let imageTruckTree;
let font;

//sons jogo
let trackSound;
let colissionSound;
let pointSound;


function preload(){
    font = loadFont("Fonte/LiquidCrystal-Bold.otf");
    imageRoad = loadImage("imagens/estrada.png");
    imageActor = loadImage("imagens/ator-2.png");
    imageCar = loadImage("imagens/carro-1.png");
    imageCarTwo = loadImage("imagens/carro-2.png");
    imageCarTree = loadImage("imagens/carro-3.png");
    imageTruck = loadImage("imagens/truck.png");
    imageTruckTwo = loadImage("imagens/truck2.png");
    imageTruckTree = loadImage("imagens/truck3.png");
    
    trackSound = loadSound("sons/trilha.mp3");
    colissionSound = loadSound("sons/colidiu.mp3");
    pointSound = loadSound("sons/pontos.wav");

    imageCars = [imageCar, imageCarTwo, imageCarTree];
    imageTrucks = [imageTruck, imageTruckTwo, imageTruckTree];
    
}