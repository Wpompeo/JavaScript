//classe carro

//var 
let xCars = [600, 600, 600];
let yCars = [45, 105, 155];
let carSpeeds = [2, 2.5, 3.2];
let widthCar = 40;
let heigthCar = 26;

function showCar(){
    for (let i = 0; i < imageCars.length; i++){
      image(imageCars[i], xCars[i], yCars[i], widthCar, heigthCar);
    } 
}
function moveCar(){
    for (let i = 0; i < imageCars.length; i++){
       xCars[i]-= carSpeeds[i];
    }    
}
function returnCar(){
    for (let i = 0; i < xCars.length; i++){
        if (exceededLimit(xCars[i])){
            xCars[i] = 600;
        }
    }    
}
function exceededLimit(xCar){
    return xCar <-50;

}
