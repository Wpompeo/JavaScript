//classe ator

//var
let xActor = 85;
let yActor = 366;
let heightActor = 30;
let widthActor = 30;
let colissionCars = false;
let collisionTrucks = false;
let points = 0;

function showActor(){
    image(imageActor, xActor, yActor, widthActor, heightActor );
}
function moveActor(){
    if(keyIsDown(UP_ARROW)){
        yActor -= 3;
    }
    if(keyIsDown(DOWN_ARROW)){
        if (canMove()){
        yActor += 3;
    }

    }
}
function checkCollisionCars(){
    for (let i = 0; i < imageCars.length; i++){
        colissionCars = collideRectCircle(xCars[i], yCars[i], heigthCar, widthCar, xActor, yActor, 15 );

        if (colissionCars){
            returnPositionActor();
            colissionSound.play();
            if (pointsGreaterZero()){  
                points -= 1;              
            }
            
        }
        
    }
}
function checkCollisionTrucks(){
    for (let i = 0; i < imageTrucks.length; i++){
         collisionTrucks = collideRectCircle(xTrucks[i], yTrucks[i], heigthTruck, widthTruck, xActor, yActor, 12.5 );
    
        if (collisionTrucks){
                returnPositionActor();
                colissionSound.play();
                if (pointsGreaterZero()){  
                    pointSound.play();
                    points -= 1;              
                }
        }
    }       
}
function returnPositionActor(){
    yActor = 366;
}
function includePoints(){
    fill(color(178, 34, 34));
    textStyle(BOLD);
    textAlign(CENTER);
    textFont(font, 30);
    text(points, width / 5, 29);
}
function scorePoints(){
    if (yActor < 15){
        points += 1;
        pointSound.play();
        returnPositionActor();
    }
}
function pointsGreaterZero(){
    return points > 0;
    
}
function canMove(){
    return yActor < 366;
}

