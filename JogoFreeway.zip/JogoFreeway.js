//cria estrada jogo.
function setup(){
    createCanvas(500, 400);
    trackSound.loop();
}
//funcao main
function draw(){
    background(imageRoad);
    showActor(); 
    showCar();   
    showTruck();
    moveTruck();
    moveCar();
    moveActor();   
    returnCar();
    returnTruck();
    checkCollisionCars();
    checkCollisionTrucks();
    includePoints();
    scorePoints();
    
}


