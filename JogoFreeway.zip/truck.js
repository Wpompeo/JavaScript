//classe caminhão

//var 
let xTrucks = [600, 600, 600];
let yTrucks = [213, 270, 318];
let truckSpeeds = [1.7, 1.4, 2.10];

let widthTruck = 70;
let heigthTruck = 28;


function showTruck(){
  for (let i = 0; i < imageTrucks.length; i++){
    image(imageTrucks[i], xTrucks[i], yTrucks[i], widthTruck, heigthTruck);
  }
}
function moveTruck(){
    xTrucks[0] -= truckSpeeds[0];
    xTrucks[1] -= truckSpeeds[1];
    xTrucks[2] -= truckSpeeds[2];
}
function returnTruck(){
    if ( xTrucks[0] <-80){
        xTrucks[0] = 600;
    }
    if ( xTrucks[1] <-80){
        xTrucks[1] = 600;
    }
    if ( xTrucks[2] <-80){
        xTrucks[2] = 600;
    }
}
